# ConvertExcelToJSON

This will tells you how we can create a JSON object from an uploaded Excel file to the browser.

For further understanding please refer :

https://ravikumarraman.blogspot.com/2020/07/how-to-convert-excel-data-into-json.html
